#include <stdio.h>
int main()
{
	printf("Learninig CMake\n");
	return 0;
}
